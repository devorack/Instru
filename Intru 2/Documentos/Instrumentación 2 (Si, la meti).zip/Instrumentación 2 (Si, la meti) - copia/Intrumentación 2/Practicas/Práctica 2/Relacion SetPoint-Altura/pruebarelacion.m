filename = ['relacion.xlsx'];
setpoin = xlsread(filename,1,'A:A');
altura = xlsread(filename,1,'B:B');

disp(setpoin);
disp(altura);