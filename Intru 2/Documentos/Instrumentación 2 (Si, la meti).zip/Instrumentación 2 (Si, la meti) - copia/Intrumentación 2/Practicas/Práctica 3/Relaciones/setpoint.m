filename = ['RelacionmaH.xlsx'];

h = xlsread(filename,1,'A:A');
ma = xlsread(filename,1,'B:B');

disp(h);
disp(ma);



