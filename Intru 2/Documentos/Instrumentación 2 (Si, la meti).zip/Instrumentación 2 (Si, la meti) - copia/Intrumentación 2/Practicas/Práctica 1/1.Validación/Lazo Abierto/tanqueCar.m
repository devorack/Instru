function dy = tanqueCar(t,y)
    global n a qi A 
    dy = (qi/(A))-(a*y^n);
end