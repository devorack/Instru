function dy = tanqueDes(t,y)
    global n a 
    dy = -(a*y^n);
end